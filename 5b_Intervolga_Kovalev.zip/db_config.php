<?php
$db_host = 'localhost';         //хост
$db_user = 'root';              //юзернейм
$db_pass = 'root';              //пароль
$db_name = 'country_list';      //имя бд
?>
